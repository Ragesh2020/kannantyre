﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyBilling.Models
{
    public class cartlist
    {
        public decimal Price { get; set; }
    }
}