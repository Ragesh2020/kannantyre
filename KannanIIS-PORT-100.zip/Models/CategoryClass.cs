﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyBilling.Models
{
    public class CategoryClass
    {
            public string Product_name;
            public List<string> Subcategory;
       
    }
}